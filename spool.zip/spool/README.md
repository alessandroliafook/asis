# Spool

Sistema de controle de impressões.

## Instalação

Para instalar o sistema é necessário ter permissão de administrador do sistema e mover os arquivos para a pasta */home*, então executar o comando de instalação do sistema.

```
$sudo install.sh
```